from cafeteria.external.v1.routes import router

__all__ = ["router"]
